package com.example.custome_listdryer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.example.custome_listdryer.databinding.ActivityDetailBinding;

public class DetailActivity extends AppCompatActivity {

    ActivityDetailBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Intent intent = getIntent();
        if (intent != null){
            String name = intent.getStringExtra("name");
            int status = intent.getIntExtra("status", R.string.StatusDryer1);
            int timeLeft = intent.getIntExtra("timeLeft", R.string.TimeLeftDryer1);
            int capacity = intent.getIntExtra("capacity", R.string.CapacityDryer1);
            int heatSource = intent.getIntExtra("heatSource", R.string.HeatSourceDryer1);
            int image = intent.getIntExtra("image", R.drawable.dryerlist);

            binding.detailName.setText(name);
            binding.detailStatus.setText(status);
            binding.detailTimeLeft.setText(timeLeft);
            binding.detailCapacity.setText(capacity);
            binding.detailHeatSource.setText(heatSource);
            binding.detailImageImageView.setImageResource(image);
        }
    }
}