package com.example.custome_listdryer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;

import com.example.custome_listdryer.databinding.ActivityMainBinding;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    ListAdapter listAdapter;
    ArrayList<ListData> dataArrayList = new ArrayList<>();
    ListData listData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        int[] imageList = {R.drawable.dryerlist,R.drawable.dryerlist,R.drawable.dryerlist};
        int[] statusList = {R.string.StatusDryer1,R.string.StatusDryer2,R.string.StatusDryer3};
        int[] timeLeftList = {R.string.TimeLeftDryer1,R.string.TimeLeftDryer2,R.string.TimeLeftDryer3 };
        int[] heatSourceList = {R.string.HeatSourceDryer1,R.string.HeatSourceDryer2,R.string.HeatSourceDryer3};
        int[] capacityList = {R.string.CapacityDryer1,R.string.CapacityDryer2,R.string.CapacityDryer3};
        String[] namelist = {"Dryer1","Dryer2","Dryer3"};

        for(int i=0; i<3; i++){
            listData = new ListData(namelist[i],statusList[i],timeLeftList[i],capacityList[i],heatSourceList[i],imageList[i]);
            dataArrayList.add(listData);
        }
        listAdapter = new ListAdapter(MainActivity.this, dataArrayList);
        binding.listview.setAdapter(listAdapter);
        binding.listview.setClickable(true);

        binding.listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this, DetailActivity.class);
                intent.putExtra("name", namelist[position]);
                intent.putExtra("status", statusList[position]);
                intent.putExtra("timeLeft", timeLeftList[position]);
                intent.putExtra("heatSource", heatSourceList[position]);
                intent.putExtra("capacity", capacityList[position]);
                intent.putExtra("image", imageList[position]);
                startActivity(intent);
            }
        });
    }

}