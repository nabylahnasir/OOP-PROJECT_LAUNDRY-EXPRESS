package com.example.custome_listdryer;

public class ListData {
    String name;
    int status,timeLeft,capacity,heatSource;
    int image;

    public ListData(String name, int status, int timeLeft, int capacity,int heatSource, int image) {
        this.name = name;
        this.status = status;
        this.timeLeft = timeLeft;
        this.capacity = capacity;
        this.image = image;
        this.heatSource = heatSource;
    }
}
