package com.example.logsignsql;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.logsignsql.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        databaseHelper = new DatabaseHelper(this);
        setContentView(binding.getRoot());
    }
}