package com.example.washer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private CardView washerone;
    private CardView washertwo;
    private CardView washerthree;
    private CardView washerfour;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolb = findViewById(R.id.toolb);
        setSupportActionBar(toolb);

        washerone = findViewById(R.id.washerone);
        washertwo = findViewById(R.id.washertwo);
        washerthree = findViewById(R.id.washerthree);
        washerfour = findViewById(R.id.washerfour);

        washerone.setOnClickListener(this);
        washertwo.setOnClickListener(this);
        washerthree.setOnClickListener(this);
        washerfour.setOnClickListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu (Menu menu){
        getMenuInflater().inflate(R.menu.toolbar_menu, menu);
        return true;
    }

    @Override
    public void onClick(View v) {
        Intent i;

        switch (v.getId()) {
            case R.id.washerone:
                i = new Intent(this, washer1.class);
                startActivity(i);
                break;
            case R.id.washertwo:
                i = new Intent(this, washer2.class);
                startActivity(i);
                break;
            case R.id.washerthree:
                i = new Intent(this, washer3.class);
                startActivity(i);
                break;
            case R.id.washerfour:
                i = new Intent(this, washer4.class);
                startActivity(i);
                break;
            default:
                break;
        }
    }
    }
